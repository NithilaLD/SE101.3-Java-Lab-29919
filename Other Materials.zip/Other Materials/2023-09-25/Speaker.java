package com.mycompany.project7;
public interface Speaker 
{
    public void speak();
}
