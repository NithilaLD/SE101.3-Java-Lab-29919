package com.mycompany.project7;
public class Person 
{
  String name;
  String city;
  int age;
  void tellName() 
  {
    System.out.println("Hello I'm " + name);
  }
}
