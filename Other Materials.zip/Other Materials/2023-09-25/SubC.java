package com.mycompany.project7;
public class SubC extends SuperB
{
    void triple() 
    {
        x = x + 3;
    }
    void quadruple() 
    {
        x = x + 4;
    }
}
