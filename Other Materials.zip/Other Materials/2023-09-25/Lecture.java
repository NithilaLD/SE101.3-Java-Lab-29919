package com.mycompany.project7;
public class Lecture extends Person
{
    String CourseID;
    void doLectures() 
    {
        System.out.println("I'm A Lecturer");
    }
}
