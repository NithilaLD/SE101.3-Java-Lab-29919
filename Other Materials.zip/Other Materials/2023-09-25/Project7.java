package com.mycompany.project7;
public class Project7 
{
    public static void main(String[] args) 
    {
        SuperB b=new SuperB();
        b.setX(2);
        b.increase();
        b.triple();
        System.out.println("SuperB "+b.returnX());
        SubC c=new SubC();
        c.setX(2);
        c.increase();
        c.triple();
        System.out.println("SubC "+c.returnX());
        //Student s=new Student();
        //s.name="Tom";
        //s.tellName();
        //s.attendLectures();
        //Lecture l=new Lecture();
        //l.name="Kamal";
        //l.tellName();
        //l.doLectures();
        //Politician po=new Politician();
        //po.speak();
        //Priest pr=new Priest();
        //pr.speak();
        //Lecturer lr=new Lecturer();
        //lr.speak();
        //Car ca=new Car();
        //ca.start();
        //ca.stop();
        //ca.accelarate();
        //ca.brake();
    }}
