package com.mycompany.project7;
public class Car implements Engine,Wheels 
{
    public void start()
    {
        System.out.println("Car's Engine Started");
    }
    public void stop()
    {
        System.out.println("Car's Engine Stooped");
    }
    public void accelarate() 
    {
        System.out.println("Car Is Accelarating");
    }
    public void brake()
    {
        System.out.println("Car Is Applying Breakes");
    }

    
    
}
