package com.mycompany.project7;
public interface Engine 
{
    public void start();
    public void stop();
}
