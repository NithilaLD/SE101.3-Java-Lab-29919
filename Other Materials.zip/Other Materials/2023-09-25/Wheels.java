package com.mycompany.project7;
public interface Wheels 
{
    public void accelarate();
    public void brake();
}
