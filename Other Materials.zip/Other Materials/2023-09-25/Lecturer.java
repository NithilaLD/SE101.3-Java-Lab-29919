package com.mycompany.project7;
public class Lecturer 
{
    public void speak() {
        System.out.println("Talk About Educational Stuff");
    }
}
