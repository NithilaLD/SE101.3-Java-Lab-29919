package com.mycompany.project7;
public class SuperB 
{
    int x;
    void setX(int n) 
    {
        x=n;
    }
    void increase() 
    {
        x=x+1;
    }
    void triple()
    {
        x=x*3;
    }
    int returnX()
    {
        return x;
    }
}
