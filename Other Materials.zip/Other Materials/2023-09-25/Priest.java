package com.mycompany.project7;
public class Priest implements Speaker{
    public void speak() {
        System.out.println("Talk About Religious Stuff");
    }
}
