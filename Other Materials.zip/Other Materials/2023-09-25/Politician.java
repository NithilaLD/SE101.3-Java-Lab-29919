package com.mycompany.project7;
public class Politician implements Speaker
{
    public void speak() {
        System.out.println("Talk About Politics");
    }
    
}
