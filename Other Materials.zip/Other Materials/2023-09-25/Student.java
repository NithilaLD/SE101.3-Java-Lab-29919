package com.mycompany.project7;
public class Student extends Person
{
    String Department;
    void attendLectures() 
    {
        System.out.println("Go To Lectures");
    }
}
