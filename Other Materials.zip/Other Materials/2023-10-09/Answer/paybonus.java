package com.mycompany.project10;
public interface paybonus 
{
    public void calcincentive();
}
