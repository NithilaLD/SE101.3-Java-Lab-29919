package com.mycompany.project10;
public class Project10 
{
    public static void main(String[] args) 
    {
        Executive ex=new Executive("1","Indika Pieris","206,Galkanuwa Road,Gorakna,Panadura","2002/04/11",20000,2000);
        ex.displayinfo();
        ex.calcincentive();
        ex.travlallownace();
    }
}
