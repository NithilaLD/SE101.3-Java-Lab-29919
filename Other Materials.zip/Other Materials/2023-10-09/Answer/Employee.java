package com.mycompany.project10;
public class Employee 
{
    String eid,name,address,dob;
    protected float salary;
    public Employee(String a,String b,String c,String d,float e)
    {
        eid=a;
        name=b;
        address=c;
        dob=d;
        salary=e;
    }
    public void displayinfo()
    {
        System.out.println("Employee ID - " + eid);
        System.out.println("Name - " + name);
        System.out.println("Address - " + address);
        System.out.println("Date Of Birth - " + dob);
        System.out.println("Salary - " + salary);
    }
}
