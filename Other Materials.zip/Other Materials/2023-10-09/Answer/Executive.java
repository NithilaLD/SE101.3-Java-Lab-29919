package com.mycompany.project10;
public class Executive extends Employee implements paybonus
{
    float t;
    public Executive(String f,String g,String h,String i,float j,float k)
    {
        super(f,g,h,i,j);
        t=k;
    }
    @Override
    public void calcincentive() 
    {
        if(salary>=5000){System.out.println("Incentive - " + salary*0.10f);}
        else {System.out.println("Incentive Is Not Paid");}
    }
    public void travlallownace()
    {
        System.out.println("Travel Allowance - " + t);
    }
    
}
