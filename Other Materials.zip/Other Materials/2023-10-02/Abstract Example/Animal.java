package com.mycompany.abstracts;
public abstract class Animal
{
    String name;
    public abstract void eat();
    public void MakeNoise()
    {
        System.out.println(name+" Make Noise");
    }
}
