package com.mycompany.abstracts;
public class Cat extends Animal
{
    @Override
    public void eat() 
    {
        System.out.println("I Eat Rats");
    }
    
}
