package com.mycompany.abstracts;
public class Abstracts 
{
    public static void main(String[] args) 
    {
        //Animal myrat=new Animal();
        Cat mycat=new Cat();
        mycat.name="Cat";
        mycat.MakeNoise();
        mycat.eat();
    }
}
