package com.mycompany.polymorphism;
public class Polymorphism 
{
    public static void main(String[] args) 
    {
        Cat mycat=new Cat();
        mycat.eat();
        mycat.eat(5);
        System.out.println("");
        Dog mydog=new Dog();
        mydog.eat();
    }
}
