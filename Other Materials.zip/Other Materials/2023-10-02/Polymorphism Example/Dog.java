package com.mycompany.polymorphism;
public class Dog extends Animal
{
    @Override
    public void eat()
    {
        System.out.println("chomp chomp chomp");
    }
}
