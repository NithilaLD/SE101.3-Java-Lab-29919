package com.mycompany.polymorphism;
public class Animal
{
    public void eat()
    {
        System.out.println("Munch");
    }
}
