package com.mycompany.polymorphism;
public class Cat extends Animal
{
    @Override
    public void eat()
    {
        System.out.println("nom nom nom");
    }
    public void eat(int no)
    {
        for (int i=0;i<no;i++)
        {
            System.out.println("nom nom nom");
        }
    }
}
