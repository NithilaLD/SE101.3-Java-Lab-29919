package com.mycompany.interfaces;
public class Interfaces 
{
    public static void main(String[] args) 
    {
        Cat mycat=new Cat();
        mycat.name="Cat";
        mycat.MakeNoise();
        mycat.Eat();
        mycat.drink();
        Dog mydog=new Dog();
        mydog.name="Dog";
        mydog.MakeNoise();
        mydog.Eat();
        mydog.drink();
        Animal a=new Animal();
    }
}
