package com.mycompany.interfaces;
public class Dog extends Animal implements Food,Drink
{

    @Override
    public void Eat() 
    {
        System.out.println("I Eat Anything");
    }

    @Override
    public void drink() {
        System.out.println("I Drink Water");
    }
    
}
