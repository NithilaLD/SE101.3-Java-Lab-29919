package com.mycompany.interfaces;
interface Food 
{
    public void Eat();
}
