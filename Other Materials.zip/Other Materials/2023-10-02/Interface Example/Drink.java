package com.mycompany.interfaces;
interface Drink 
{
    public void drink();
}
