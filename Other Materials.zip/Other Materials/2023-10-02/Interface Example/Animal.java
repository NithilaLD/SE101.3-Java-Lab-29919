package com.mycompany.interfaces;
public class Animal
{
    String name;
    public void MakeNoise()
    {
        System.out.println(name+" Make Noise");
    }
}
