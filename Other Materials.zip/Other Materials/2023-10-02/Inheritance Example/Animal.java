package com.mycompany.inheritance;
public class Animal extends Inheritance
{
    String name;
    public void MakeNoise()
    {
        System.out.println(name+" Make Noise");
    }
}
