package com.mycompany.inheritance;
public class Cat extends Animal
{
    
}
