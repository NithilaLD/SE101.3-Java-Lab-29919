package com.mycompany.inheritance;
public class Dog extends Animal
{
    
}
