package com.mycompany.inheritance;
public class Inheritance 
{
    public static void main(String[] args) 
    {
        Cat mycat=new Cat();
        mycat.name="Cat";
        mycat.MakeNoise();
        Dog mydog=new Dog();
        mydog.name="Dog";
        mydog.MakeNoise();
    }
}
