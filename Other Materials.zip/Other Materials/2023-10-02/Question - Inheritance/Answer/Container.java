package com.mycompany.project8;
public abstract class Container 
{
    public abstract Double Volume();
}
