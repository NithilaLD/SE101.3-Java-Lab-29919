package com.mycompany.project8;
import java.util.Scanner;
public class Project8 
{
    public static void main(String[] args) 
    {
        System.out.println("Calculating Voulume Of A Cylinder\n");
        double he,ra;
        Scanner sc1=new Scanner(System.in);
        System.out.print("Enter Height Of The Cylinder - ");
        he=sc1.nextDouble();
        Scanner sc2=new Scanner(System.in);
        System.out.print("Enter Radius Of The Cylinder - ");
        ra=sc2.nextDouble();
        CylindricalContainer cc=new CylindricalContainer(he,ra);
        System.out.println("\nVolume Of The Cylinder - "+cc.Volume());
    }
}
