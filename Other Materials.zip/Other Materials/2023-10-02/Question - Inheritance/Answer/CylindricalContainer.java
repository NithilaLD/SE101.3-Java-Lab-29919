package com.mycompany.project8;
public class CylindricalContainer extends Container
{
    private double height,radius,PI=3.14159;
    public CylindricalContainer(double R,double H)
    {
        height=H;
        radius=R;
    }
    @Override
    public Double Volume() 
    {
        return (PI*radius*radius*height);
    }
    
}
