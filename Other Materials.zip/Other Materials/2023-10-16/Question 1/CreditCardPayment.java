package com.mycompany.question1;
public class CreditCardPayment 
{
    public void paymentMethod()
    {
        //.......
    }
}
