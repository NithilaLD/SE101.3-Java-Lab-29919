package com.mycompany.question1;
public interface Payment 
{
    public void paymentmethod();
}
