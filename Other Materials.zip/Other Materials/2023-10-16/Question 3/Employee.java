package com.mycompany.question3;
public class Employee 
{
    int empno;
    String dept;
    static String cname="NSBM";
    public Employee(int a,String b)
    {
        empno=a;
        dept=b;
    }
    public void display()
    {
        System.out.println("Employee No - "+ empno);
        System.out.println("Department - " + dept);
        System.out.println("Company Name - " + cname);
    }
}
