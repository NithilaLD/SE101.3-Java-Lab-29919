package com.mycompany.question3;
public class Question3 
{
    public static void main(String[] args) 
    {
        Employee c=new Employee(29919,"Department Of Network And Security");
        c.display();
    }
}
