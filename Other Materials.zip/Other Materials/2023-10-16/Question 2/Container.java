package com.mycompany.question2;
public abstract class Container 
{
    public abstract Double Volume();
}
