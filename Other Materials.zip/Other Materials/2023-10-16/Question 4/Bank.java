package com.mycompany.question4;
public abstract class Bank 
{
    public abstract double getrateofinterest();
}
