package com.mycompany.question4;
public class Question4 
{
    public static void main(String[] args) 
    {
        SBI a=new SBI();
        System.out.println("SBI Bank Interest Rate - " +a.getrateofinterest());
        ICICI b=new ICICI();
        System.out.println("ICICI Bank Interest Rate - " +b.getrateofinterest());
        AXIS c=new AXIS();
        System.out.println("Axis Bank Interest Rate - " +c.getrateofinterest());
    }
}
