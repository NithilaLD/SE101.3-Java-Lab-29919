package com.mycompany.question4;
public class ICICI extends Bank
{
    public double getrateofinterest()
    {
        return 0.07;
    }
}
