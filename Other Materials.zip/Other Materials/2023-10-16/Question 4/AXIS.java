package com.mycompany.question4;
public class AXIS extends Bank
{
    public double getrateofinterest()
    {
        return 0.09;
    }
}
