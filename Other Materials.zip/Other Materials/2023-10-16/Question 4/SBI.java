package com.mycompany.question4;
public class SBI extends Bank
{
    public double getrateofinterest()
    {
        return 0.08;
    }
}
