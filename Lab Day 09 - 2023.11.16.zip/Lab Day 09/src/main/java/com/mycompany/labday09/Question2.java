package com.mycompany.labday09;

public class Question2 implements Runnable
{
    public void run()
    {
        for(int i=1;i<6;i++)
        {
            try
            {
                Thread.sleep(500);
            }
            catch(Exception e)
            {
                
            }
            System.out.println(i);
        }
    }
    public static void main(String[] args)
    {
        Question1 q1=new Question1();
        Thread t1=new Thread(q1);
        t1.start();
        Question1 q2=new Question1();
        Thread t2=new Thread(q1);
        t2.start();
    }
}
