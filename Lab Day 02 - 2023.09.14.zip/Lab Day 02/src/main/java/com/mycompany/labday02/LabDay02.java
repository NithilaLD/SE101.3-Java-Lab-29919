package com.mycompany.labday02;
import java.util.Scanner;
public class LabDay02 
{
    public static void main(String[] args) 
    {
        int a;
        String b;
        Scanner sc1=new Scanner(System.in);
        System.out.println("Enter A Location");
        a=sc1.nextInt();
        Scanner sc2=new Scanner(System.in);
        System.out.println("Enter A Description");
        b=sc2.nextLine();
        Item c=new Item(a,b);
        System.out.println("Location - "+c.getLocation());
        System.out.println("Description - "+c.getDescription());
        
    }
}
