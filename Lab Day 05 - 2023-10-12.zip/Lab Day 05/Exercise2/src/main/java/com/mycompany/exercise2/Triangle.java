package com.mycompany.exercise2;
public class Triangle implements Shape
{
    double height,base,l1,l2;

    public Triangle(double a,double b,double c,double d)
    {
        height=a;
        base=b;
        l1=c;
        l2=d;
    }
    @Override
    public double calculateArea() 
    {
        return (base*height)/2;
    }

    @Override
    public double calculatePerimeter() 
    {
        return base+l1+l2;
    }
    
}
