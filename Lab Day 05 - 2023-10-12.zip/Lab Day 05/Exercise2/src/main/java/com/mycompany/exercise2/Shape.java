package com.mycompany.exercise2;
public interface Shape 
{
    public double calculateArea();
    public double calculatePerimeter();
}
