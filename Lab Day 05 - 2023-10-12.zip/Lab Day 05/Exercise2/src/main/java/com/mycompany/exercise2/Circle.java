package com.mycompany.exercise2;
public class Circle implements Shape
{
    double radius,pi=3.14159;
    public Circle(double a)
    {
        radius=a;
    }
    @Override
    public double calculateArea() 
    {
        return pi*radius*radius;
    }

    @Override
    public double calculatePerimeter() 
    {
        return 2*pi*radius;
    }
    
}
