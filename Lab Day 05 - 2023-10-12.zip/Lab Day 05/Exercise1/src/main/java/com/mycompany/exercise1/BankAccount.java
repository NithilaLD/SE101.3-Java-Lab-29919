package com.mycompany.exercise1;
public abstract class BankAccount 
{
    String ano;
    double balance;
    public void setano(String a)
    {
        ano=a;
    }
    public void setbalance(double b)
    {
        balance=b;
    }
    public String getano()
    {
        return ano;
    }
    public double getbalance()
    {
        return balance;
    }
    public abstract double calculateinstrest();
}
