package com.mycompany.exercise1;
public class Exercise1 
{
    public static void main(String[] args) 
    {
        CheckingAccount c=new CheckingAccount();
        c.setano("5555666778");
        c.setbalance(2000000);
        System.out.println("Account Number - " + c.getano());
        System.out.println("Balance - " + c.getbalance());
        System.out.println("Interest - " + c.calculateinstrest());
        SavingsAccount s=new SavingsAccount();
        s.setano("1111222334");
        s.setbalance(20000000);
        System.out.println("Account Number - " + s.getano());
        System.out.println("Balance - " + s.getbalance());
        System.out.println("Interest - " + s.calculateinstrest());
        
    }
}
